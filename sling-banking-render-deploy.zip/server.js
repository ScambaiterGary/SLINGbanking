// SLING Banking fictional demo API
// Local-only: binds to 127.0.0.1. In-memory demo data resets when restarted.
const http = require("http");
const fs = require("fs");
const path = require("path");

const HOST = "0.0.0.0";
const PORT = process.env.PORT || 3000;
const PAGE = path.join(__dirname, "sling-banking-demo.html");

let balance = 24680.50;
let transactions = [
  { company: "Coffee & Such", amount: 4.80, type: "debit", time: "Today · 09:42" },
  { company: "Definitely Real Payroll", amount: 2400, type: "credit", time: "Yesterday · 08:15" },
  { company: "Plant-Based Decisions", amount: 29.99, type: "debit", time: "04 Nov · 16:03" },
  { company: "Pixel Palace", amount: 12.50, type: "debit", time: "03 Nov · 20:11" }
];

function send(res, status, data) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Access-Control-Allow-Origin": "same-origin"
  });
  res.end(JSON.stringify(data));
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", chunk => {
      body += chunk;
      if (body.length > 10_000) {
        reject(new Error("Request body too large"));
        req.destroy();
      }
    });
    req.on("end", () => {
      try { resolve(JSON.parse(body || "{}")); }
      catch { reject(new Error("Send valid JSON")); }
    });
    req.on("error", reject);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${HOST}:${PORT}`);

  if (req.method === "GET" && url.pathname === "/api/state") {
    return send(res, 200, { demo: true, currency: "GBP", balance, transactions });
  }

  if (req.method === "POST" && url.pathname === "/api/transactions") {
    try {
      const input = await readJson(req);
      const company = typeof input.company === "string" ? input.company.trim().slice(0, 48) : "";
      const amount = Number(input.amount);
      const type = input.type;

      if (!company) return send(res, 400, { error: "company is required" });
      if (!Number.isFinite(amount) || amount <= 0 || amount > 1000000)
        return send(res, 400, { error: "amount must be between 0.01 and 1,000,000" });
      if (type !== "credit" && type !== "debit")
        return send(res, 400, { error: "type must be credit or debit" });

      const rounded = Math.round(amount * 100) / 100;
      if (type === "debit" && rounded > balance)
        return send(res, 409, { error: "Not enough fictional demo funds" });

      balance = Math.round((balance + (type === "credit" ? rounded : -rounded)) * 100) / 100;
      const tx = {
        company,
        amount: rounded,
        type,
        time: new Date().toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" }) + " · DEMO"
      };
      transactions.unshift(tx);
      transactions = transactions.slice(0, 50);
      return send(res, 201, { demo: true, balance, transaction: tx });
    } catch (err) {
      return send(res, 400, { error: err.message || "Bad request" });
    }
  }

  if (req.method === "GET" && (url.pathname === "/" || url.pathname === "/index.html")) {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
    return fs.createReadStream(PAGE).pipe(res);
  }

  if (req.method === "GET" && url.pathname === "/health") {
    return send(res, 200, { ok: true, app: "SLING fictional demo API" });
  }

  res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
  res.end("Not found");
});

server.listen(PORT, HOST, () => {
  console.log(`SLING demo server listening on port ${PORT}`);
  console.log("Local-only fictional simulator. No real banking or payment functions.");
});
